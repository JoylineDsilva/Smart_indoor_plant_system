import tensorflow as tf 
import json
import cv2
import numpy as np
from PIL import Image
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
from tensorflow.keras.preprocessing.image import ImageDataGenerator

def preprocess_image(filepath):
    """
    Preprocesses an image given its filepath for prediction.
    Args:
        filepath (str): Path to the image file.
    Returns:
        np.array: Preprocessed image array.
    """
    try:
        # Open the image from the file path
        img = Image.open(filepath)

        # Resize the image to the required size (224x224 for MobileNetV2)
        img = img.resize((224, 224))

        # Convert the image to a numpy array
        img_array = np.array(img)

        # Normalize and preprocess the image for the model
        img_array = img_array / 255.0  # Normalize
        img_array = preprocess_input(img_array)  # Preprocessing for MobileNetV2

        # Expand dimensions to match model input (batch_size, height, width, channels)
        img_array = np.expand_dims(img_array, axis=0)

        # Ensure image is in the correct dtype (float32)
        img_array = img_array.astype(np.float32)

        return img_array

    except Exception as e:
        print(f"Error preprocessing image: {e}")
        raise ValueError(f"Failed to preprocess image: {e}")

# Function to capture image from webcam
def capture_image_from_webcam():
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Error: Could not open webcam.")
        return None

    ret, frame = cap.read()
    if ret:
        # Optionally, save the captured image to disk for testing or manual prediction
        cv2.imwrite('captured_image.jpg', frame)

    cap.release()
    cv2.destroyAllWindows()

    return frame

# Function to load the model and class indices
def load_model_and_class_indices(model_path, class_indices_path):
    try:
        # Load the trained model
        model = tf.keras.models.load_model(model_path)

        # Load the class indices
        with open(class_indices_path, 'r') as f:
            class_indices = json.load(f)

        print("Model and class indices loaded successfully.")
        return model, class_indices

    except Exception as e:
        print(f"Error loading model or class indices: {e}")
        raise ValueError(f"Failed to load model or class indices: {e}")

def preprocess_image_for_prediction(image):
    """
    Preprocesses an image for prediction: resize, normalize, and apply MobileNetV2 preprocessing.

    Args:
    - image (PIL.Image or np.array): The image to preprocess.

    Returns:
    - image_array (np.array): Preprocessed image array ready for model prediction.
    """
    try:
        if isinstance(image, np.ndarray):  # Handle cases where input is already a numpy array
            image = Image.fromarray(image)

        # Resize the image
        image = image.resize((224, 224))

        # Convert image to numpy array and normalize
        image_array = np.array(image, dtype=np.float32) / 255.0

        # Apply MobileNetV2 preprocessing
        image_array = preprocess_input(image_array)

        # Expand dimensions to match model input (batch_size, height, width, channels)
        image_array = np.expand_dims(image_array, axis=0)

        return image_array

    except Exception as e:
        print(f"Error preprocessing image for prediction: {e}")
        raise ValueError(f"Failed to preprocess image for prediction: {e}")

# Function to handle prediction using the trained model
def make_prediction(model, image_array):
    """
    Make a prediction using the trained model.

    Args:
    - model (tf.keras.Model): The trained model.
    - image_array (np.array): The preprocessed image array.

    Returns:
    - str: The predicted class label.
    """
    try:
        # Make the prediction
        predictions = model.predict(image_array)
        
        # Get the index of the highest prediction score
        predicted_class_index = np.argmax(predictions[0])

        # Retrieve the class label using the class indices
        class_label = class_indices[str(predicted_class_index)]

        return class_label
    except Exception as e:
        print(f"Error making prediction: {e}")
        raise ValueError(f"Failed to make prediction: {e}")
